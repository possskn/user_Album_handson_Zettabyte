import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { UsersService } from '../service/users.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  private usersList:User[] =[];
  constructor(private userServiceObj:UsersService) { }

  ngOnInit() {

    this.userServiceObj.getUsers().subscribe(
      (usersResponse)=>this.usersList = usersResponse
    );
      
  }

}
