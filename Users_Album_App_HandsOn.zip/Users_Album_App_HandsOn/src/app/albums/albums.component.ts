import { Component, OnInit } from '@angular/core';
import { UsersService } from '../service/users.service';
import { ActivatedRoute, Router, ActivatedRouteSnapshot } from '@angular/router';
import { Album } from '../models/album';

@Component({
  selector: 'app-albums',
  templateUrl: './albums.component.html',
  styleUrls: ['./albums.component.css']
})
export class AlbumsComponent implements OnInit {

  constructor(private userServiceObj:UsersService,
    private currRoute:ActivatedRoute) { }
  private userId:number;
  private albumsForUser:Album[] = [];

  ngOnInit() {
    this.currRoute.params.subscribe(
      p => this.userId = p.userId
    );    
    this.userServiceObj.getAlbumsForUser(this.userId).subscribe(
      (albumsResponse)=> {
        this.albumsForUser = albumsResponse;
      }
    );
  }

}
