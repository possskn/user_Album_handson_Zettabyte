import { Component, OnInit } from '@angular/core';
import { Photo } from '../models/photos';
import { UsersService } from '../service/users.service';
import { filter } from 'rxjs/operators';
import { ActivatedRoute, Router, NavigationStart, NavigationEnd } from '@angular/router';
import { Location, PathLocationStrategy, LocationStrategy } from '@angular/common';

@Component({
  selector: 'app-photos',
  templateUrl: './photos.component.html',
  styleUrls: ['./photos.component.css']
})
export class PhotosComponent implements OnInit {

  private photosList: Photo[] = [];
  private firstFivePhotos: Photo[] = [];
  private albumId: number;

  constructor(private userServiceObj: UsersService,
    private currRoute: ActivatedRoute) { 

  }

  ngOnInit() {
    this.currRoute.params.subscribe(
      p => this.albumId = p.albumId
    );
    this.userServiceObj.getPhotosForAlbum(this.albumId).subscribe(
      (photosResponse) => {
        this.photosList = photosResponse;
        this.firstFivePhotos = this.photosList.slice(0, 5);
      }
    );
   
  } 
}
