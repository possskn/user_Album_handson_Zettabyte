import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsersComponent } from './users/users.component';
import { AlbumsComponent } from './albums/albums.component';
import { PhotosComponent } from './photos/photos.component';
import { ErrorComponent } from './error/error.component';

const routes: Routes = [
  { path: '', component: UsersComponent },
  { path: 'user/:userId/albums', component: AlbumsComponent },
  { path: 'album/:albumId/photos', component: PhotosComponent },
  { path: '**', component: ErrorComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
