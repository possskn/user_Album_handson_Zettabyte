export class User {
    constructor(private id?:number,
    private name?:string,
    private username?:string,
    private email?:string,
    private address?:any,
    private phone?:string,
    private website?:string,
    private company?:any){}
}