import { Photos } from './photos';

describe('Photos', () => {
  it('should create an instance', () => {
    expect(new Photos()).toBeTruthy();
  });
});
