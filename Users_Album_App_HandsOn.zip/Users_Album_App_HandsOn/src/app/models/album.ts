export class Album {
    constructor(private id?:number,
    private userId?:number,
    private title?:string
    ){}
}
