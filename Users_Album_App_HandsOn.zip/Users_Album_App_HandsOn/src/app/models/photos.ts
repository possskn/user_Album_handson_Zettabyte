export class Photo {
    constructor(
        private  albumId?:number,
        private id?: number,
        private title?: string,
        private url?: string,
        private thumbnailUrl?:string
    ){

    }
}
