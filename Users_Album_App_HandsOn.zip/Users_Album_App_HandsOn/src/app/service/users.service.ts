import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../models/user';
import { Album } from '../models/album';
import { Photo } from '../models/photos';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private httpServObj: HttpClient) { }

  getUsers(): Observable<User[]> {
    return this.httpServObj.get<User[]>('https://jsonplaceholder.typicode.com/users');
  }

  getAlbumsForUser(userId: number): Observable<Album[]> {
    return this.httpServObj.get<Album[]>(`http://jsonplaceholder.typicode.com/albums?userId=${userId}`);
  }
  
  getPhotosForAlbum(albumId: number): Observable<Photo[]> {
    return this.httpServObj.get<Photo[]>(`http://jsonplaceholder.typicode.com/photos?=albumId=${albumId}`);
  }
}
